package com.onlinepizza.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlinepizza.model.Coupan;

public interface ICoupanRepository extends JpaRepository<Coupan, Integer>{


}