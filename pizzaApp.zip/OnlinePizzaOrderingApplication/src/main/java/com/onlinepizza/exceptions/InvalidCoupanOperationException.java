package com.onlinepizza.exceptions;

public class InvalidCoupanOperationException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidCoupanOperationException(String message) {
		super(message);
	}
}
