package com.onlinepizza.exceptions;

public class PizzaIdNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PizzaIdNotFoundException(String message) {
		super(message);
	}
}
